ser.write(text1.encode())
    # ser.write(text2.encode())
    # ser.write(text3.encode())